<?php
/**
 * Plugin Name: AlgebraHub
 * Plugin URI: https://docs.algebrahub.com/plugins/wordpress/
 * Description: Running AlgebraHub tools on your Wordpress website
 * Requires PHP: 7.2
 */


//include('general.php');                           // general types and functionality
//include('settings.php');                          // defines settings page
include('shortcode.php');                         // defines AlgebraHub tools (search bar)

