# AlgebraKiT WordPress Plugin

A Plugin to enable AlgebraKiT exercises on WordPress websites.

Installation instructions for this plugin can be found here: (https://docs.algebrakit-learning.com/plugins/wordpress/)

---

**AlgebraKiT**<br>
Official Website: (https://algebrakit-learning.com)<br>
Documentation: (https://docs.algebrakit-learning.com)